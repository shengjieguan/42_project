/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/16 13:34:26 by shguan            #+#    #+#             */
/*   Updated: 2019/11/15 12:23:26 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

static int		ft_find(char *str, char c)
{
	int	i;

	i = 0;
	while (str[i] && str[i] != c)
		i++;
	return (i);
}

static int		ft_final(char **s, char **line, int fd)
{
	*line = ft_strdup(s[fd]);
	ft_memdel((void**)&s[fd]);
	return (1);
}

static int		ft_newline(char **s, char **line, int fd)
{
	size_t	len;
	char	*tmp;

	len = ft_find(s[fd], '\n');
	*line = ft_strsub(s[fd], 0, len);
	tmp = ft_strdup(s[fd] + len + 1);
	free(s[fd]);
	s[fd] = tmp;
	if (s[fd][0] == '\0')
		ft_memdel((void**)&s[fd]);
	return (1);
}

int				get_next_line(const int fd, char **line)
{
	static char	*s[4096];
	char		buf[BUFF_SIZE + 1];
	char		*tmp;
	int			ret;

	if (fd < 0 || fd > 4096 || line == NULL)
		return (-1);
	if (s[fd] == NULL)
		s[fd] = ft_memalloc(1);
	while ((ret = read(fd, buf, BUFF_SIZE)) > 0)
	{
		buf[ret] = '\0';
		tmp = s[fd];
		s[fd] = ft_strjoin(tmp, buf);
		free(tmp);
		if (ft_strrchr(buf, '\n'))
			return (ft_newline(s, line, fd));
	}
	if (ft_strrchr(s[fd], '\n'))
		return (ft_newline(s, line, fd));
	if (ret < 0)
		return (-1);
	if (ret == 0 && (s[fd] == NULL || s[fd][0] == '\0'))
		return (0);
	return (ft_final(s, line, fd));
}
