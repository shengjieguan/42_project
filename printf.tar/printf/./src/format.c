/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   format.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 11:31:48 by shguan            #+#    #+#             */
/*   Updated: 2019/11/29 13:23:25 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

char	*ft_length(char *format, t_tab *arg)
{
	char *s;

	s = "hljtzqL";
	if (*format == *(format + 1) && (*format == 'h' || *format == 'l'))
	{
		(*format == 'h') && (arg->length = "hh");
		(*format == 'l') && (arg->length = "ll");
		return (format + 2);
	}
	else if (ft_strchr(s, *format))
	{
		(*format == 'L') && (arg->length = "L");
		(*format == 'h') && (arg->length = "h");
		(*format == 'l') && (arg->length = "l");
		(*format == 'j') && (arg->length = "j");
		(*format == 't') && (arg->length = "t");
		(*format == 'z') && (arg->length = "z");
		(*format == 'q') && (arg->length = "q");
		return (format + 1);
	}
	return (format);
}

char	*ft_pres_nb(char *format, t_tab *arg)
{
	if (*format == '.')
	{
		format++;
		arg->pres = 1;
		if (ft_isdigit(*format))
			arg->pres_nb = 0;
		while (ft_isdigit(*format))
			arg->pres_nb = arg->pres_nb * 10 + *format++ - '0';
	}
	return (format);
}

char	*ft_width_nb(char *format, t_tab *arg)
{
	arg->width_nb = 0;
	while (ft_isdigit(*format))
		arg->width_nb = arg->width_nb * 10 + *format++ - '0';
	return (format);
}

char	*ft_flag(char *format, t_tab *arg)
{
	while (*format == '-' || *format == ' ' || *format == '+' ||
			*format == '#' || *format == '0')
	{
		(*format == '0') && (arg->flag_zero = 1);
		(*format == '-') && (arg->flag_minus = 1);
		(*format == ' ') && (arg->flag_space = 1);
		(*format == '+') && (arg->flag_plus = 1);
		(*format == '#') && (arg->flag_hash = 1);
		(arg->flag_minus) && (arg->flag_zero = 0);
		(arg->flag_plus) && (arg->flag_space = 0);
		format++;
	}
	return (format);
}

int		print_zero(t_tab *arg, char c)
{
	(arg->flag_zero && !arg->pres) && (write(1, "0", 1) && write(1, &c, 1));
	(arg->width_nb -= 2) && (arg->len += 2);
	return (1);
}
