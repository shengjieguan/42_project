/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ftoa.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/09 09:39:20 by shguan            #+#    #+#             */
/*   Updated: 2019/12/13 15:40:38 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

static char	*ft_itoa_sign(intmax_t n)
{
	size_t	len;
	size_t	i;
	char	tmp[255];
	char	*ret;

	len = 0;
	if (!n)
		tmp[len++] = '0';
	while (n)
	{
		tmp[len++] = n % 10 + '0';
		n /= 10;
	}
	ret = ft_strnew(len);
	i = -1;
	while (++i < len && ret)
		ret[i] = tmp[len - 1 - i];
	if (ret)
		ret[len] = 0;
	return (ret);
}

void		print_float_str(int count, int zero, int i, char *s)
{
	while (count-- > 0)
	{
		write(1, "0", 1) && i--;
		if (i == 0 && zero)
			write(1, ".", 1);
		zero--;
	}
	while (i >= 0)
	{
		zero--;
		write(1, s++, 1) && i--;
		if (i == 0 && zero)
			write(1, ".", 1);
	}
	if (zero > 0)
	{
		zero -= ft_strlen(s);
		write(1, "0", zero);
		(ft_strlen(s) > 0) && write(1, s, ft_strlen(s));
	}
}

void		float_to_int(t_tab *arg, long double num, intmax_t num_int)
{
	intmax_t	n;
	int			i;
	char		*s;
	int			count;
	int			zero;

	i = ft_countnbr_signed(num_int, 10);
	count = arg->pres_nb;
	zero = arg->pres_nb + i;
	while (arg->pres_nb-- > 0)
		num *= 10;
	num += 0.000001l;
	n = (long double)(num / 1);
	if ((num - n) > 0.500001l)
		n++;
	s = ft_itoa_sign(n);
	count = count + i - ft_strlen(s);
	print_float_str(count, zero, i, s);
}
