/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_unsigned.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 11:16:59 by shguan            #+#    #+#             */
/*   Updated: 2019/11/29 11:17:17 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_putnbr_unsigned(uintmax_t n, int base)
{
	uintmax_t tmp;

	tmp = (uintmax_t)n;
	if (!n && n != 0)
	{
		ft_putchar('-');
		tmp *= -1;
	}
	if (tmp > 9)
		ft_putnbr_unsigned(tmp / base, base);
	ft_putchar(tmp % base + '0');
}
