/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_c.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/18 13:25:13 by shguan            #+#    #+#             */
/*   Updated: 2019/11/29 12:00:21 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

int		print_c(t_tab *arg, va_list ap)
{
	char c;
	char sign;

	sign = (arg->flag_zero ? '0' : ' ');
	c = va_arg(ap, int);
	if (arg->width_nb > 1 && !arg->flag_minus)
		print_pad(--arg->width_nb, arg, sign);
	write(1, &c, 1);
	if (arg->width_nb > 1 && arg->flag_minus)
		print_pad(--arg->width_nb, arg, sign);
	arg->len += 1;
	return (arg->len);
}
