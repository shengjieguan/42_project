/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_f.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 09:52:58 by shguan            #+#    #+#             */
/*   Updated: 2019/12/06 17:10:59 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

void		ft_float_neg(t_tab *arg, long double num, char c, intmax_t num_int)
{
	(num *= -1);
	num_int *= -1;
	arg->width_nb -= (arg->pres_nb == 0 ? 1 : 2);
	arg->width_nb -= (arg->pres_nb + ft_countnbr_signed(num_int, 10));
	if (arg->width_nb && !arg->flag_minus)
		print_pad(arg->width_nb, arg, c);
	write(1, "-", 1);
	if (arg->pres_nb == 0)
	{
		if ((num - num_int) > 0.500000l)
			num_int++;
		ft_putnbr_signed(num_int, 10);
		(arg->flag_hash) && write(1, ".", 1);
	}
	if (arg->pres_nb)
		float_to_int(arg, num, num_int);
	if (arg->width_nb && arg->flag_minus)
		print_pad(arg->width_nb, arg, c);
}

void		ft_float_pos(t_tab *arg, long double num, char c, intmax_t num_int)
{
	arg->width_nb--;
	arg->width_nb -= (arg->pres_nb + ft_countnbr_signed(num_int, 10));
	(arg->pres_nb == 0) && arg->width_nb++;
	if (arg->flag_plus || arg->flag_space)
	{
		arg->width_nb--;
		arg->len++;
		(arg->flag_zero && arg->flag_plus) && write(1, "+", 1);
		(arg->flag_space) && write(1, " ", 1);
	}
	if (arg->width_nb > 0 && !arg->flag_minus)
		print_pad(arg->width_nb, arg, c);
	if (arg->pres_nb == 0)
	{
		if ((num - num_int) > 0.500000l)
			num_int++;
		ft_putnbr_signed(num_int, 10);
		(arg->flag_hash) && write(1, ".", 1);
	}
	if (arg->flag_plus && !arg->flag_zero)
		write(1, "+", 1);
	if (arg->pres_nb)
		float_to_int(arg, num, num_int);
	if (arg->width_nb && arg->flag_minus)
		print_pad(arg->width_nb, arg, c);
}

void		ft_float_zero(t_tab *arg, char c)
{
	(arg->flag_plus) && arg->width_nb--;
	(arg->flag_plus && arg->flag_minus) && write(1, "+", 1);
	print_pad(arg->width_nb, arg, c);
	(arg->flag_plus && !arg->flag_minus) && write(1, "+", 1);
	arg->len--;
}

int			print_lf(t_tab *arg, va_list ap)
{
	long double	num;
	intmax_t	num_int;
	char		c;

	c = (arg->flag_zero ? '0' : ' ');
	if (arg->length)
	{
		if (!ft_strcmp(arg->length, "L"))
			num = (long double)va_arg(ap, long double);
		if (!ft_strcmp(arg->length, "l"))
			num = (long double)va_arg(ap, double);
	}
	else
		num = (long double)va_arg(ap, double);
	num_int = (long double)(num / 1);
	(arg->pres_nb == -1) && (arg->pres_nb = 6);
	arg->len += ft_countnbr_signed(num_int, 10) + 1 + arg->pres_nb;
	if (!num && arg->pres && arg->pres_nb < 1 && !arg->width)
		ft_float_zero(arg, c);
	else if (num >= 0)
		ft_float_pos(arg, num, c, num_int);
	else if (num < 0)
		ft_float_neg(arg, num, c, num_int);
	return (arg->len);
}
