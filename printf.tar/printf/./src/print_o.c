/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_o.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 10:07:07 by shguan            #+#    #+#             */
/*   Updated: 2019/11/29 10:53:33 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

int		print_o_result(t_tab *arg, uintmax_t num, char c, int arg_len)
{
	if (!arg->flag_hash && arg->pres_nb < 1 && arg->pres && !num)
	{
		if (arg->width_nb > 0)
			print_pad(++arg->width_nb, arg, c);
		return (--arg->len);
	}
	if (arg->width_nb > 0 && !arg->flag_minus)
		print_pad(arg->width_nb, arg, c);
	if (arg->pres_nb > 0)
		print_pad(arg->pres_nb - arg_len, arg, '0');
	if (arg->flag_hash && num != 0 && arg->pres_nb <= arg_len)
		write(1, "0", 1) && arg->len++;
	ft_putnbr_unsigned(num, 8);
	if (arg->width_nb > 0 && arg->flag_minus)
		print_pad(arg->width_nb, arg, c);
	return (arg->len);
}

int		print_o(t_tab *arg, va_list ap)
{
	int			arg_len;
	uintmax_t	num;
	char		c;

	c = (arg->flag_zero ? '0' : ' ');
	num = num_uintmax_t(arg, ap);
	(arg_len = ft_countnbr_unsigned(num, 8)) && (arg->len += arg_len);
	(arg->flag_hash && num != 0) && arg->width_nb--;
	(arg->pres) && (c = ' ');
	arg->width_nb -= (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
	return (print_o_result(arg, num, c, arg_len));
}
