/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_s.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 12:00:46 by shguan            #+#    #+#             */
/*   Updated: 2019/11/29 12:03:55 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

void	display(t_tab *arg, char c, char *str)
{
	int	n;

	n = arg->width_nb - ft_strlen(str);
	if (n > 0)
	{
		arg->len += n;
		while (n-- > 0)
			write(1, &c, 1);
	}
}

int		print_s(t_tab *arg, va_list ap)
{
	char	*str;
	char	c;
	int		arg_len;

	str = va_arg(ap, char *);
	c = (arg->flag_zero == 1 ? '0' : ' ');
	if (str == NULL)
		str = "(null)";
	arg_len = ft_strlen(str);
	if (arg->pres && arg->pres_nb > -1)
		arg_len = (arg->pres_nb > arg_len ? arg_len : arg->pres_nb);
	(arg->pres_nb == -1 && arg->pres) && (arg_len = 0);
	arg->width_nb -= arg_len;
	if (!arg->flag_minus && arg->width_nb)
		print_pad(arg->width_nb, arg, c);
	write(1, str, arg_len);
	if (arg->flag_minus == 1 && arg->width_nb)
		print_pad(arg->width_nb, arg, ' ');
	arg->len += arg_len;
	return (arg->len);
}
