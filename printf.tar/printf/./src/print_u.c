/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_u.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 10:38:58 by shguan            #+#    #+#             */
/*   Updated: 2019/12/03 14:55:02 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

static int	ft_num_zero(t_tab *arg, char c)
{
	(arg->flag_plus) && arg->width_nb--;
	(arg->flag_plus && arg->flag_minus) && write(1, "+", 1);
	print_pad(arg->width_nb, arg, c);
	(arg->flag_plus && !arg->flag_minus) && write(1, "+", 1);
	arg->len--;
	return (arg->len);
}

int			print_u(t_tab *arg, va_list ap)
{
	int			arg_len;
	uintmax_t	num;
	char		c;

	c = (arg->flag_zero == 1 ? '0' : ' ');
	num = num_uintmax_t(arg, ap);
	(arg_len = ft_countnbr_unsigned(num, 10)) && (arg->len += arg_len);
	(arg->pres == 1) && (c = ' ');
	if ((arg->pres == 1 && arg->pres_nb < 1) && num == 0)
		return (ft_num_zero(arg, c));
	arg->width_nb -= (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
	if (arg->width_nb > 0 && arg->flag_minus == 0)
		print_pad(arg->width_nb, arg, c);
	if (arg->pres_nb > 0)
		print_pad(arg->pres_nb - arg_len, arg, '0');
	ft_putnbr_unsigned(num, 10);
	if (arg->width_nb > 0 && arg->flag_minus == 1)
		print_pad(arg->width_nb, arg, c);
	return (arg->len);
}
