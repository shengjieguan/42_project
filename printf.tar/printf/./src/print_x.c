/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_x.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 11:54:27 by shguan            #+#    #+#             */
/*   Updated: 2019/12/03 15:16:48 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

static int	pres_nb(t_tab *arg, uintmax_t num, int arg_len)
{
	(arg->flag_plus && (num || num == 0)) && (write(1, "+", 1));
	if (!num && num != 0)
		write(1, "-", 1) && (num *= -1) && arg->pres_nb++;
	print_pad(arg->pres_nb - arg_len, arg, '0');
	return (1);
}

static int	width_nb(t_tab *arg, intmax_t num, char c)
{
	(arg->pres_nb < 1 && arg->pres && !num) && arg->width_nb++;
	if (num < 0 && !arg->pres && arg->flag_zero)
		write(1, "-", 1) && (num *= -1);
	(arg->flag_plus && num >= 0) && arg->width_nb--;
	print_pad(arg->width_nb, arg, c);
	return (1);
}

static int	ft_num_zero(t_tab *arg, char c)
{
	arg->width_nb++;
	(arg->flag_plus) && arg->width_nb--;
	(arg->flag_plus && arg->flag_minus) && write(1, "+", 1);
	print_pad(arg->width_nb, arg, c);
	(arg->flag_plus && !arg->flag_minus) && write(1, "+", 1);
	return (arg->len);
}

int			print_x_result(t_tab *arg, uintmax_t num, char sign)
{
	if (arg->width_nb > 0 && arg->flag_minus)
		width_nb(arg, num, sign);
	return (arg->len);
}

int			print_x(t_tab *arg, va_list ap, char c)
{
	uintmax_t	num;
	char		*str;
	int			arg_len;
	char		sign;

	sign = (arg->flag_zero > 0 ? '0' : ' ');
	(arg->pres) && (sign = ' ');
	num = num_uintmax_t(arg, ap);
	str = ft_itoa_uintmax_t(num, 16, c);
	arg_len = ft_strlen(str);
	arg->width_nb -= (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
	if (arg->pres_nb < 1 && arg->pres && !num)
	{
		free(str);
		return (ft_num_zero(arg, sign));
	}
	(arg->flag_plus && (num || num == 0) && !arg->pres) && write(1, "+", 1);
	(arg->flag_hash == 1 && num != 0) && print_zero(arg, c);
	(arg->width_nb > 0 && !arg->flag_minus) && width_nb(arg, num, sign);
	if (arg->flag_hash == 1 && num != 0 && (!arg->flag_zero || arg->pres))
		write(1, "0", 1) && write(1, &c, 1);
	(arg->pres_nb > 0) && pres_nb(arg, num, arg_len);
	write(1, str, arg_len) && (arg->len += arg_len);
	free(str);
	return (print_x_result(arg, num, sign));
}
